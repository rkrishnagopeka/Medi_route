# MediRoute — Architecture Overview

## System Diagram

```
┌─────────────────────────────────────────────────────────┐
│                     CLIENT LAYER                         │
│                                                          │
│  Flutter App (Android / iOS / Web)                       │
│  ├── Triage Screen   ──────────────► Gemini API          │
│  ├── Facility Map    ──────────────► Google Maps SDK      │
│  ├── CHW Screen      ──────────────► Firebase Firestore  │
│  └── Analytics       ──────────────► Looker Studio embed │
└─────────────────────┬───────────────────────────────────┘
                       │ HTTPS
┌─────────────────────▼───────────────────────────────────┐
│                  BACKEND LAYER (Cloud Run)                │
│                                                          │
│  Node.js Express API                                     │
│  ├── /api/triage      → Gemini API proxy + logging       │
│  └── /api/facilities  → Firestore read/write             │
└─────────────────────┬───────────────────────────────────┘
                       │
┌─────────────────────▼───────────────────────────────────┐
│                    DATA LAYER                            │
│                                                          │
│  Firebase Firestore  ─ Real-time facility + CHW data     │
│  Firebase Auth       ─ Anonymous + phone auth            │
│  Firebase Messaging  ─ CHW push alerts                   │
│  Vertex AI           ─ Localized disease model (v2)      │
│  Hive (local)        ─ Offline triage + facility cache   │
└─────────────────────────────────────────────────────────┘
```

## Data Collections (Firestore)

### `facilities`
| Field | Type | Description |
|---|---|---|
| name | string | Facility display name |
| type | enum | hospital/clinic/pharmacy/chw |
| status | enum | open/closed/busy |
| lat, lng | number | Coordinates |
| waitMinutes | number | Current wait time |
| hasEmergency | boolean | Has emergency dept |
| availableMeds | string[] | In-stock medications |

### `chws`
| Field | Type | Description |
|---|---|---|
| name | string | CHW display name |
| phone | string | Contact number |
| lat, lng | number | Current location |
| available | boolean | Currently available |
| languages | string[] | Languages spoken |

### `triage_events` (analytics)
| Field | Type | Description |
|---|---|---|
| urgencyLevel | string | emergency/urgent/home_care |
| location | GeoPoint | De-identified location |
| language | string | Language used |
| timestamp | Timestamp | Event time |

## Offline Strategy

Core triage data is cached locally using Hive. On first load:
1. Fetch top 20 nearby facilities → cache to Hive box `facilities`
2. Cache last triage result → available offline
3. CHW list → cached with 1hr TTL

When offline, Maps and live data features show cached versions with a banner indicating offline mode.

## Localization (i18n)

Currently supported: English, Hindi, Tamil, Telugu, Swahili, Spanish.
Gemini API handles language switching natively via the prompt.
Static UI strings use Flutter's `intl` package with `.arb` files.
