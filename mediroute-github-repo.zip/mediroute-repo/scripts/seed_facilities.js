/**
 * MediRoute — Firestore Facility Seeder
 * Run: node scripts/seed_facilities.js
 *
 * Populates Firestore with 20 mock health facilities for demo/testing.
 * Uses Chennai, India coordinates as defaults (easy to change).
 */

const admin = require('firebase-admin');
const serviceAccount = require('../service-account.json'); // Add your service account file

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});

const db = admin.firestore();

const facilities = [
  {
    name: 'AIIMS Annexe Clinic',
    type: 'hospital',
    status: 'open',
    lat: 13.0827, lng: 80.2707,
    address: '1st Cross St, Chennai',
    waitMinutes: 18,
    hasEmergency: true,
    availableMeds: ['Paracetamol', 'ORS', 'Amoxicillin'],
    phone: '+91-44-2890-0000',
    rating: 4.3,
  },
  {
    name: 'PHC Velachery',
    type: 'clinic',
    status: 'open',
    lat: 12.9795, lng: 80.2209,
    address: 'Velachery Main Rd, Chennai',
    waitMinutes: 8,
    hasEmergency: false,
    availableMeds: ['Paracetamol', 'ORS', 'Iron tablets'],
    phone: '+91-44-2244-0012',
    rating: 3.9,
  },
  {
    name: 'MedPlus Pharmacy',
    type: 'pharmacy',
    status: 'open',
    lat: 13.0604, lng: 80.2496,
    address: 'Anna Nagar, Chennai',
    waitMinutes: 3,
    hasEmergency: false,
    availableMeds: ['Paracetamol', 'Antacids', 'BP meds', 'Insulin'],
    phone: '+91-44-2662-0044',
    rating: 4.1,
  },
  {
    name: 'CHW Priya Devi',
    type: 'chw',
    status: 'open',
    lat: 13.0900, lng: 80.2800,
    address: 'Perambur, Chennai',
    waitMinutes: 25,
    hasEmergency: false,
    availableMeds: [],
    phone: '+91-98400-11111',
    rating: 4.8,
  },
  {
    name: 'Stanley Hospital',
    type: 'hospital',
    status: 'busy',
    lat: 13.1100, lng: 80.2900,
    address: 'Old Jail Rd, Chennai',
    waitMinutes: 45,
    hasEmergency: true,
    availableMeds: ['Full formulary'],
    phone: '+91-44-2528-4500',
    rating: 3.7,
  },
  {
    name: 'Adyar Clinic',
    type: 'clinic',
    status: 'open',
    lat: 13.0012, lng: 80.2565,
    address: 'Gandhi Nagar, Adyar',
    waitMinutes: 12,
    hasEmergency: false,
    availableMeds: ['Paracetamol', 'Dolo-650', 'ORS', 'Cetirizine'],
    phone: '+91-44-2441-0055',
    rating: 4.2,
  },
  {
    name: 'GRH Emergency',
    type: 'hospital',
    status: 'open',
    lat: 13.0450, lng: 80.2530,
    address: 'Park Town, Chennai',
    waitMinutes: 30,
    hasEmergency: true,
    availableMeds: ['Full formulary'],
    phone: '+91-44-2530-5100',
    rating: 3.5,
  },
  {
    name: 'Community Health Post K7',
    type: 'clinic',
    status: 'closed',
    lat: 13.0700, lng: 80.2600,
    address: 'Kilpauk, Chennai',
    waitMinutes: null,
    hasEmergency: false,
    availableMeds: [],
    phone: null,
    rating: 3.2,
  },
];

async function seed() {
  console.log('🌱 Seeding facilities to Firestore...');
  const batch = db.batch();

  for (const facility of facilities) {
    const ref = db.collection('facilities').doc();
    batch.set(ref, {
      ...facility,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
    });
  }

  await batch.commit();
  console.log(`✅ Seeded ${facilities.length} facilities successfully.`);
  process.exit(0);
}

seed().catch((err) => {
  console.error('❌ Seed failed:', err);
  process.exit(1);
});
