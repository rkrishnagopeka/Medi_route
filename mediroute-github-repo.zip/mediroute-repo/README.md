# 🏥 MediRoute — AI-Powered Emergency & Chronic Care Navigator

> **Bridging the last mile in healthcare access for underserved communities.**

[![Flutter](https://img.shields.io/badge/Flutter-3.x-02569B?logo=flutter)](https://flutter.dev)
[![Firebase](https://img.shields.io/badge/Firebase-Firestore%20%2B%20Auth-FFCA28?logo=firebase)](https://firebase.google.com)
[![Gemini AI](https://img.shields.io/badge/Gemini-AI%20Triage-4285F4?logo=google)](https://ai.google.dev)
[![Google Maps](https://img.shields.io/badge/Google%20Maps-Platform-34A853?logo=googlemaps)](https://developers.google.com/maps)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)

---

## 🌍 The Problem

Every day, millions of people — especially in developing regions — face this crisis:

> *"My child has a fever. The nearest clinic is 40km away, I don't know if it's open, I don't know if they have medicine, and I can't afford to go if it's a wasted trip."*

People delay or skip medical care not because they don't want it, but because of:
- No real-time info on clinic availability / wait times
- Language barriers when describing symptoms
- No guidance on whether something is an emergency
- Zero coordination between community health workers and hospitals

**This kills people. Silently. Daily.**

---

## 💡 The Solution

MediRoute is a **Flutter mobile app + web dashboard** that acts as an intelligent medical navigation and triage system for communities with limited healthcare access.

### Core Features

| Feature | Description | Tech |
|---|---|---|
| 🤖 **AI Symptom Triage** | Voice/text symptom input → Urgency classification in local language | Gemini API |
| 🗺️ **Live Facility Finder** | Nearby clinics/pharmacies with real-time availability & wait times | Google Maps Platform |
| 👩‍⚕️ **CHW Network** | Links patients to volunteer Community Health Workers for home visits | Firebase |
| 📴 **Offline Mode** | Core triage + facility data works without internet | Firebase Local Persistence |
| 📊 **Analytics Dashboard** | Disease hotspots, clinic load, unmet need for NGOs & health ministries | Looker Studio |

---

## 🛠️ Tech Stack

```
Flutter (Android / iOS / Web)
├── Gemini API          → Multilingual symptom triage AI
├── Google Maps SDK     → Facility discovery + routing
├── Firebase Auth       → User authentication
├── Cloud Firestore     → Real-time data + offline sync
├── Firebase Messaging  → CHW push notifications
├── Google Cloud Run    → Scalable backend (Node.js)
├── Vertex AI           → Localized disease-pattern model
└── Looker Studio       → Health analytics dashboard
```

---

## 🎯 UN SDGs Covered

- **SDG 3** — Good Health & Well-Being *(Core mission: reduce preventable deaths)*
- **SDG 10** — Reduced Inequalities *(Targets the underserved, not the insured)*
- **SDG 11** — Sustainable Cities *(Smart community health infrastructure)*

---

## 🚀 Quick Start

### Prerequisites

- Flutter SDK 3.x ([install guide](https://flutter.dev/docs/get-started/install))
- Node.js 18+ (for backend)
- Firebase CLI: `npm install -g firebase-tools`
- A Google Cloud project with Maps + Gemini APIs enabled

### 1. Clone the repository

```bash
git clone https://github.com/YOUR_USERNAME/mediroute.git
cd mediroute
```

### 2. Configure environment

```bash
cp .env.example .env
# Fill in your API keys in .env
```

### 3. Set up Firebase

```bash
firebase login
firebase use --add   # select your Firebase project
flutterfire configure
```

### 4. Install dependencies & run

```bash
flutter pub get
flutter run
```

For the web prototype (no setup needed):
```bash
open web/prototype/index.html
```

---

## 📁 Project Structure

```
mediroute/
├── lib/
│   ├── main.dart                    # App entry point
│   ├── app.dart                     # Root widget + routing
│   ├── screens/
│   │   ├── splash_screen.dart
│   │   ├── home_screen.dart
│   │   ├── triage_screen.dart       # AI Symptom Checker
│   │   ├── facility_map_screen.dart # Live Facility Finder
│   │   ├── chw_screen.dart          # Community Health Workers
│   │   └── analytics_screen.dart   # Dashboard
│   ├── widgets/
│   │   ├── stat_card.dart
│   │   ├── facility_tile.dart
│   │   ├── triage_result_card.dart
│   │   └── language_pill.dart
│   ├── services/
│   │   ├── gemini_service.dart      # Triage AI calls
│   │   ├── maps_service.dart        # Facility search
│   │   ├── firebase_service.dart    # Auth + Firestore
│   │   └── chw_service.dart         # CHW alert system
│   └── models/
│       ├── facility.dart
│       ├── triage_result.dart
│       └── chw.dart
├── backend/
│   ├── index.js                     # Cloud Run API
│   ├── routes/
│   │   ├── triage.js
│   │   └── facilities.js
│   └── package.json
├── web/
│   ├── prototype/
│   │   └── index.html               # Interactive web prototype
│   └── demo/
│       └── index.html               # Cinematic demo video
├── docs/
│   ├── MediRoute_Pitch_Deck.pptx
│   └── architecture.md
├── scripts/
│   └── seed_facilities.js           # Seed mock facility data to Firestore
├── test/
│   └── widget_test.dart
├── pubspec.yaml
├── .env.example
├── .gitignore
├── firebase.json
└── README.md
```

---

## 🔑 Environment Variables

Create a `.env` file at the root (never commit this):

```env
GEMINI_API_KEY=your_gemini_api_key_here
GOOGLE_MAPS_API_KEY=your_maps_api_key_here
FIREBASE_PROJECT_ID=your_firebase_project_id
```

---

## 🌱 Seeding Demo Data

To populate Firestore with 20 mock health facilities for testing:

```bash
cd scripts
node seed_facilities.js
```

---

## 📸 Screenshots

| Triage Screen | Facility Map | CHW Network | Analytics |
|---|---|---|---|
| *(AI symptom checker)* | *(Live map view)* | *(CHW alert system)* | *(Health dashboard)* |

> See `/web/prototype/index.html` for the full interactive prototype.

---

## 🤝 Contributing

1. Fork the repo
2. Create your feature branch: `git checkout -b feature/my-feature`
3. Commit your changes: `git commit -m 'Add my feature'`
4. Push to the branch: `git push origin feature/my-feature`
5. Open a Pull Request

---

## 📄 License

This project is licensed under the MIT License — see the [LICENSE](LICENSE) file for details.

---

## 👥 Team

Built with ❤️ for underserved communities worldwide.

> *MediRoute — Because every life deserves a route to care.*
