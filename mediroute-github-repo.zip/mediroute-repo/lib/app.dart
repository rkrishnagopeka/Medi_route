import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import 'screens/splash_screen.dart';
import 'screens/home_screen.dart';
import 'screens/triage_screen.dart';
import 'screens/facility_map_screen.dart';
import 'screens/chw_screen.dart';
import 'screens/analytics_screen.dart';

class MediRouteApp extends StatelessWidget {
  const MediRouteApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'MediRoute',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF0C0F14),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF1D9E75),
          secondary: Color(0xFF378ADD),
          error: Color(0xFFE24B4A),
          surface: Color(0xFF1E2736),
          background: Color(0xFF0C0F14),
        ),
        textTheme: GoogleFonts.soraTextTheme(
          ThemeData.dark().textTheme,
        ),
        cardTheme: CardTheme(
          color: const Color(0xFF1E2736),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          elevation: 0,
        ),
      ),
      initialRoute: '/splash',
      routes: {
        '/splash': (context) => const SplashScreen(),
        '/home': (context) => const HomeScreen(),
        '/triage': (context) => const TriageScreen(),
        '/facilities': (context) => const FacilityMapScreen(),
        '/chw': (context) => const ChwScreen(),
        '/analytics': (context) => const AnalyticsScreen(),
      },
    );
  }
}
