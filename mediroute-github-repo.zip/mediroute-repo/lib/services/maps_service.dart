import 'dart:convert';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;

import '../models/facility.dart';

class MapsService {
  static String get _apiKey => dotenv.env['GOOGLE_MAPS_API_KEY'] ?? '';
  static const String _placesUrl =
      'https://maps.googleapis.com/maps/api/place/nearbysearch/json';
  static const String _directionsUrl =
      'https://maps.googleapis.com/maps/api/directions/json';

  /// Gets the current device location.
  static Future<Position> getCurrentLocation() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) throw Exception('Location services are disabled.');

    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        throw Exception('Location permissions are denied');
      }
    }

    return await Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.high,
    );
  }

  /// Searches for nearby health facilities using Google Places API.
  static Future<List<Facility>> searchNearbyFacilities({
    required double lat,
    required double lng,
    int radiusMeters = 10000,
    String type = 'hospital',
  }) async {
    final uri = Uri.parse(_placesUrl).replace(queryParameters: {
      'location': '$lat,$lng',
      'radius': '$radiusMeters',
      'type': type,
      'key': _apiKey,
    });

    final response = await http.get(uri);
    if (response.statusCode != 200) {
      throw Exception('Places API error: ${response.statusCode}');
    }

    final data = jsonDecode(response.body);
    final results = data['results'] as List<dynamic>? ?? [];

    return results
        .map((place) => Facility.fromPlacesApi(place))
        .take(20)
        .toList();
  }

  /// Gets driving directions between two points.
  static Future<Map<String, dynamic>> getDirections({
    required double originLat,
    required double originLng,
    required double destLat,
    required double destLng,
  }) async {
    final uri = Uri.parse(_directionsUrl).replace(queryParameters: {
      'origin': '$originLat,$originLng',
      'destination': '$destLat,$destLng',
      'mode': 'driving',
      'key': _apiKey,
    });

    final response = await http.get(uri);
    final data = jsonDecode(response.body);

    if (data['status'] != 'OK') {
      throw Exception('Directions API: ${data['status']}');
    }

    final leg = data['routes'][0]['legs'][0];
    return {
      'distance': leg['distance']['text'],
      'duration': leg['duration']['text'],
      'steps': leg['steps'],
    };
  }

  /// Calculates distance in km between two coordinates.
  static double distanceBetween(
    double lat1, double lng1, double lat2, double lng2) {
    return Geolocator.distanceBetween(lat1, lng1, lat2, lng2) / 1000;
  }
}
