import 'dart:convert';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:http/http.dart' as http;

import '../models/triage_result.dart';

/// Handles all Gemini API calls for symptom triage.
class GeminiService {
  static const String _baseUrl =
      'https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent';

  static String get _apiKey => dotenv.env['GEMINI_API_KEY'] ?? '';

  /// Triages symptoms and returns a [TriageResult].
  /// [symptoms] — free-text or transcribed voice input
  /// [language] — ISO 639-1 code: 'en', 'hi', 'ta', etc.
  static Future<TriageResult> triageSymptoms({
    required String symptoms,
    String language = 'en',
  }) async {
    final prompt = _buildTriagePrompt(symptoms, language);

    final response = await http.post(
      Uri.parse('$_baseUrl?key=$_apiKey'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'contents': [
          {
            'parts': [
              {'text': prompt}
            ]
          }
        ],
        'generationConfig': {
          'temperature': 0.2,
          'maxOutputTokens': 512,
        },
        'safetySettings': [
          {
            'category': 'HARM_CATEGORY_MEDICAL',
            'threshold': 'BLOCK_NONE',
          }
        ],
      }),
    );

    if (response.statusCode != 200) {
      throw Exception('Gemini API error: ${response.statusCode}');
    }

    final data = jsonDecode(response.body);
    final text =
        data['candidates']?[0]?['content']?['parts']?[0]?['text'] ?? '';

    return TriageResult.fromGeminiResponse(text);
  }

  static String _buildTriagePrompt(String symptoms, String language) {
    return '''
You are MediRoute's AI triage assistant. A patient from an underserved community has described their symptoms. 
Provide a structured triage response in $language.

Patient symptoms: "$symptoms"

Respond ONLY in valid JSON with this exact structure:
{
  "urgency": "emergency" | "urgent" | "home_care",
  "urgencyLabel": "Go Now Immediately" | "Visit Clinic Soon" | "Home Care Recommended",
  "urgencySubtitle": "Brief subtitle in plain language",
  "explanation": "2-3 sentence plain-language explanation appropriate for low-literacy users",
  "nextStep": "Single most important next action",
  "confidence": 0-100,
  "redFlags": ["list", "of", "warning", "signs", "to", "watch"],
  "homeRemedies": ["tip1", "tip2"] // only if urgency is home_care
}

Rules:
- Use simple language a non-medical person understands
- Never diagnose — only triage
- Be compassionate and clear
- Confidence should reflect certainty of triage level, not diagnosis
''';
  }
}
