import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';

import '../models/facility.dart';
import '../models/chw.dart';

class FirebaseService extends ChangeNotifier {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final FirebaseMessaging _messaging = FirebaseMessaging.instance;

  User? get currentUser => _auth.currentUser;

  // ── AUTH ────────────────────────────────────────────────────────

  Future<UserCredential> signInAnonymously() async {
    final cred = await _auth.signInAnonymously();
    notifyListeners();
    return cred;
  }

  Future<void> signOut() async {
    await _auth.signOut();
    notifyListeners();
  }

  // ── MESSAGING ───────────────────────────────────────────────────

  static Future<void> initMessaging() async {
    final messaging = FirebaseMessaging.instance;
    await messaging.requestPermission();
    FirebaseMessaging.onBackgroundMessage(_backgroundMessageHandler);
  }

  @pragma('vm:entry-point')
  static Future<void> _backgroundMessageHandler(RemoteMessage message) async {
    debugPrint('Background FCM: ${message.notification?.title}');
  }

  // ── FACILITIES ──────────────────────────────────────────────────

  /// Fetches nearby facilities from Firestore within [radiusKm].
  Future<List<Facility>> getNearbyFacilities({
    required double lat,
    required double lng,
    double radiusKm = 10,
  }) async {
    // Approximate bounding box (1 deg ≈ 111 km)
    final delta = radiusKm / 111.0;
    final snapshot = await _db
        .collection('facilities')
        .where('lat', isGreaterThan: lat - delta)
        .where('lat', isLessThan: lat + delta)
        .get();

    return snapshot.docs
        .map((doc) => Facility.fromFirestore(doc))
        .where((f) => (f.lng - lng).abs() < delta)
        .toList();
  }

  /// Live stream of facility updates (for real-time availability).
  Stream<List<Facility>> facilitiesStream({
    required double lat,
    required double lng,
    double radiusKm = 10,
  }) {
    final delta = radiusKm / 111.0;
    return _db
        .collection('facilities')
        .where('lat', isGreaterThan: lat - delta)
        .where('lat', isLessThan: lat + delta)
        .snapshots()
        .map((snap) => snap.docs
            .map((doc) => Facility.fromFirestore(doc))
            .where((f) => (f.lng - lng).abs() < delta)
            .toList());
  }

  // ── COMMUNITY HEALTH WORKERS ────────────────────────────────────

  Future<List<Chw>> getNearbyCHWs({
    required double lat,
    required double lng,
  }) async {
    final delta = 0.05; // ~5km
    final snap = await _db
        .collection('chws')
        .where('lat', isGreaterThan: lat - delta)
        .where('lat', isLessThan: lat + delta)
        .where('available', isEqualTo: true)
        .get();

    return snap.docs.map((doc) => Chw.fromFirestore(doc)).toList();
  }

  Future<void> requestCHWVisit({
    required String chwId,
    required String patientId,
    required String symptoms,
  }) async {
    await _db.collection('chw_requests').add({
      'chwId': chwId,
      'patientId': patientId,
      'symptoms': symptoms,
      'status': 'pending',
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  // ── ANALYTICS ───────────────────────────────────────────────────

  Future<void> logTriageEvent({
    required String urgencyLevel,
    required double lat,
    required double lng,
    required String language,
  }) async {
    await _db.collection('triage_events').add({
      'urgencyLevel': urgencyLevel,
      'location': GeoPoint(lat, lng),
      'language': language,
      'timestamp': FieldValue.serverTimestamp(),
    });
  }
}
