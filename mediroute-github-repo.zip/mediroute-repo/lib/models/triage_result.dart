import 'dart:convert';

enum UrgencyLevel { emergency, urgent, homeCare }

class TriageResult {
  final UrgencyLevel urgency;
  final String urgencyLabel;
  final String urgencySubtitle;
  final String explanation;
  final String nextStep;
  final int confidence;
  final List<String> redFlags;
  final List<String> homeRemedies;

  const TriageResult({
    required this.urgency,
    required this.urgencyLabel,
    required this.urgencySubtitle,
    required this.explanation,
    required this.nextStep,
    required this.confidence,
    this.redFlags = const [],
    this.homeRemedies = const [],
  });

  factory TriageResult.fromGeminiResponse(String rawText) {
    try {
      // Strip markdown code fences if present
      final cleaned = rawText
          .replaceAll(RegExp(r'```json|```'), '')
          .trim();
      final data = jsonDecode(cleaned) as Map<String, dynamic>;

      final urgencyStr = data['urgency'] as String? ?? 'home_care';
      final urgency = switch (urgencyStr) {
        'emergency' => UrgencyLevel.emergency,
        'urgent' => UrgencyLevel.urgent,
        _ => UrgencyLevel.homeCare,
      };

      return TriageResult(
        urgency: urgency,
        urgencyLabel: data['urgencyLabel'] ?? 'Assessment Complete',
        urgencySubtitle: data['urgencySubtitle'] ?? '',
        explanation: data['explanation'] ?? '',
        nextStep: data['nextStep'] ?? '',
        confidence: (data['confidence'] as num?)?.toInt() ?? 70,
        redFlags: List<String>.from(data['redFlags'] ?? []),
        homeRemedies: List<String>.from(data['homeRemedies'] ?? []),
      );
    } catch (_) {
      // Fallback result on parse error
      return const TriageResult(
        urgency: UrgencyLevel.urgent,
        urgencyLabel: 'Please Consult a Doctor',
        urgencySubtitle: 'Could not fully assess — please seek care',
        explanation:
            'We were unable to fully analyze your symptoms. Please visit the nearest health facility.',
        nextStep: 'Visit nearest clinic or call a CHW',
        confidence: 50,
      );
    }
  }
}
