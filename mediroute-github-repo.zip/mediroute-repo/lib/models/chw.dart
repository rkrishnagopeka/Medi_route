import 'package:cloud_firestore/cloud_firestore.dart';

class Chw {
  final String id;
  final String name;
  final String phone;
  final double lat;
  final double lng;
  final bool available;
  final List<String> languages;
  final String? photoUrl;
  final int casesHandled;

  const Chw({
    required this.id,
    required this.name,
    required this.phone,
    required this.lat,
    required this.lng,
    required this.available,
    this.languages = const ['en'],
    this.photoUrl,
    this.casesHandled = 0,
  });

  factory Chw.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return Chw(
      id: doc.id,
      name: data['name'] ?? '',
      phone: data['phone'] ?? '',
      lat: (data['lat'] as num).toDouble(),
      lng: (data['lng'] as num).toDouble(),
      available: data['available'] ?? false,
      languages: List<String>.from(data['languages'] ?? ['en']),
      photoUrl: data['photoUrl'],
      casesHandled: data['casesHandled'] ?? 0,
    );
  }
}
