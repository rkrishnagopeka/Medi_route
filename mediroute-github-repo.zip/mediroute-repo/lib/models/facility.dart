import 'package:cloud_firestore/cloud_firestore.dart';

enum FacilityType { hospital, clinic, pharmacy, chw }

enum FacilityStatus { open, closed, busy }

class Facility {
  final String id;
  final String name;
  final FacilityType type;
  final FacilityStatus status;
  final double lat;
  final double lng;
  final String address;
  final int? waitMinutes;
  final bool hasEmergency;
  final List<String> availableMeds;
  final String? phone;
  final double? rating;

  const Facility({
    required this.id,
    required this.name,
    required this.type,
    required this.status,
    required this.lat,
    required this.lng,
    required this.address,
    this.waitMinutes,
    this.hasEmergency = false,
    this.availableMeds = const [],
    this.phone,
    this.rating,
  });

  factory Facility.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return Facility(
      id: doc.id,
      name: data['name'] ?? '',
      type: FacilityType.values.firstWhere(
        (t) => t.name == data['type'],
        orElse: () => FacilityType.clinic,
      ),
      status: FacilityStatus.values.firstWhere(
        (s) => s.name == data['status'],
        orElse: () => FacilityStatus.open,
      ),
      lat: (data['lat'] as num).toDouble(),
      lng: (data['lng'] as num).toDouble(),
      address: data['address'] ?? '',
      waitMinutes: data['waitMinutes'],
      hasEmergency: data['hasEmergency'] ?? false,
      availableMeds: List<String>.from(data['availableMeds'] ?? []),
      phone: data['phone'],
      rating: (data['rating'] as num?)?.toDouble(),
    );
  }

  factory Facility.fromPlacesApi(Map<String, dynamic> place) {
    return Facility(
      id: place['place_id'] ?? '',
      name: place['name'] ?? '',
      type: FacilityType.clinic,
      status: place['opening_hours']?['open_now'] == true
          ? FacilityStatus.open
          : FacilityStatus.closed,
      lat: place['geometry']['location']['lat'].toDouble(),
      lng: place['geometry']['location']['lng'].toDouble(),
      address: place['vicinity'] ?? '',
      rating: (place['rating'] as num?)?.toDouble(),
    );
  }

  Map<String, dynamic> toMap() => {
        'name': name,
        'type': type.name,
        'status': status.name,
        'lat': lat,
        'lng': lng,
        'address': address,
        'waitMinutes': waitMinutes,
        'hasEmergency': hasEmergency,
        'availableMeds': availableMeds,
        'phone': phone,
        'rating': rating,
      };
}
