import 'package:flutter/material.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;

  final List<_NavItem> _navItems = [
    _NavItem(icon: Icons.home_outlined, label: 'Home'),
    _NavItem(icon: Icons.medical_services_outlined, label: 'Triage'),
    _NavItem(icon: Icons.map_outlined, label: 'Facilities'),
    _NavItem(icon: Icons.people_outline, label: 'CHW'),
    _NavItem(icon: Icons.bar_chart_outlined, label: 'Analytics'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0C0F14),
      body: _buildBody(),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _selectedIndex,
        onDestinationSelected: (i) => setState(() => _selectedIndex = i),
        backgroundColor: const Color(0xFF131820),
        destinations: _navItems
            .map((item) => NavigationDestination(
                  icon: Icon(item.icon),
                  label: item.label,
                ))
            .toList(),
      ),
    );
  }

  Widget _buildBody() {
    switch (_selectedIndex) {
      case 0:
        return _buildDashboard();
      case 1:
        return _buildTriageShortcut();
      case 2:
        return _buildFacilityShortcut();
      case 3:
        return _buildCHWShortcut();
      case 4:
        return _buildAnalyticsShortcut();
      default:
        return _buildDashboard();
    }
  }

  Widget _buildDashboard() {
    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 40, height: 40,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFF1D9E75), Color(0xFF0d7a5a)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Icon(Icons.emergency, color: Colors.white, size: 20),
                ),
                const SizedBox(width: 10),
                const Text('MediRoute',
                    style: TextStyle(
                        fontSize: 20, fontWeight: FontWeight.bold)),
                const Spacer(),
                IconButton(
                  icon: const Icon(Icons.notifications_outlined),
                  onPressed: () {},
                ),
              ],
            ),
            const SizedBox(height: 20),

            // SOS Button
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xFFE24B4A).withOpacity(0.1),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: const Color(0xFFE24B4A).withOpacity(0.3)),
              ),
              child: Row(
                children: [
                  const Icon(Icons.sos, color: Color(0xFFE24B4A), size: 32),
                  const SizedBox(width: 12),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Emergency SOS',
                            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                        Text('Tap for immediate help',
                            style: TextStyle(color: Colors.white54, fontSize: 12)),
                      ],
                    ),
                  ),
                  FilledButton(
                    onPressed: () => _showSOSDialog(),
                    style: FilledButton.styleFrom(backgroundColor: const Color(0xFFE24B4A)),
                    child: const Text('SOS'),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // Quick actions
            const Text('Quick Actions',
                style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
            const SizedBox(height: 10),
            GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisSpacing: 10,
              mainAxisSpacing: 10,
              childAspectRatio: 1.6,
              children: [
                _QuickActionCard(
                  icon: Icons.bolt,
                  label: 'Symptom Triage',
                  subtitle: 'AI-powered',
                  color: const Color(0xFF1D9E75),
                  onTap: () => Navigator.pushNamed(context, '/triage'),
                ),
                _QuickActionCard(
                  icon: Icons.map,
                  label: 'Find Care',
                  subtitle: 'Near you',
                  color: const Color(0xFF378ADD),
                  onTap: () => Navigator.pushNamed(context, '/facilities'),
                ),
                _QuickActionCard(
                  icon: Icons.people,
                  label: 'CHW Network',
                  subtitle: 'Home visit',
                  color: const Color(0xFF7F77DD),
                  onTap: () => Navigator.pushNamed(context, '/chw'),
                ),
                _QuickActionCard(
                  icon: Icons.bar_chart,
                  label: 'Analytics',
                  subtitle: 'Health trends',
                  color: const Color(0xFFBA7517),
                  onTap: () => Navigator.pushNamed(context, '/analytics'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _showSOSDialog() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Emergency SOS'),
        content: const Text(
            'This will alert emergency services and nearby CHWs with your location.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(
            onPressed: () => Navigator.pop(ctx),
            style: FilledButton.styleFrom(backgroundColor: const Color(0xFFE24B4A)),
            child: const Text('Activate SOS'),
          ),
        ],
      ),
    );
  }

  Widget _buildTriageShortcut() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Navigator.pushNamed(context, '/triage');
      setState(() => _selectedIndex = 0);
    });
    return const SizedBox.shrink();
  }

  Widget _buildFacilityShortcut() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Navigator.pushNamed(context, '/facilities');
      setState(() => _selectedIndex = 0);
    });
    return const SizedBox.shrink();
  }

  Widget _buildCHWShortcut() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Navigator.pushNamed(context, '/chw');
      setState(() => _selectedIndex = 0);
    });
    return const SizedBox.shrink();
  }

  Widget _buildAnalyticsShortcut() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Navigator.pushNamed(context, '/analytics');
      setState(() => _selectedIndex = 0);
    });
    return const SizedBox.shrink();
  }
}

class _NavItem {
  final IconData icon;
  final String label;
  const _NavItem({required this.icon, required this.label});
}

class _QuickActionCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final String subtitle;
  final Color color;
  final VoidCallback onTap;

  const _QuickActionCard({
    required this.icon,
    required this.label,
    required this.subtitle,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: color.withOpacity(0.25)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Icon(icon, color: color, size: 24),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label,
                    style: const TextStyle(
                        fontWeight: FontWeight.w600, fontSize: 13)),
                Text(subtitle,
                    style: TextStyle(color: color, fontSize: 11)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
