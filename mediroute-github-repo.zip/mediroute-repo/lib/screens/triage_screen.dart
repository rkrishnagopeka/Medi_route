import 'package:flutter/material.dart';
import 'package:speech_to_text/speech_to_text.dart';
import 'package:geolocator/geolocator.dart';

import '../services/gemini_service.dart';
import '../services/firebase_service.dart';
import '../models/triage_result.dart';
import '../widgets/triage_result_card.dart';
import '../widgets/language_pill.dart';

class TriageScreen extends StatefulWidget {
  const TriageScreen({super.key});

  @override
  State<TriageScreen> createState() => _TriageScreenState();
}

class _TriageScreenState extends State<TriageScreen> {
  final TextEditingController _symptomController = TextEditingController();
  final SpeechToText _speech = SpeechToText();

  String _selectedLang = 'en';
  bool _isListening = false;
  bool _isAnalyzing = false;
  TriageResult? _result;
  String? _error;

  final List<Map<String, String>> _languages = [
    {'code': 'en', 'label': 'English'},
    {'code': 'hi', 'label': 'हिन्दी'},
    {'code': 'ta', 'label': 'தமிழ்'},
    {'code': 'te', 'label': 'తెలుగు'},
    {'code': 'sw', 'label': 'Swahili'},
    {'code': 'es', 'label': 'Español'},
  ];

  @override
  void dispose() {
    _symptomController.dispose();
    super.dispose();
  }

  Future<void> _startListening() async {
    final available = await _speech.initialize();
    if (!available) return;

    setState(() => _isListening = true);
    _speech.listen(
      onResult: (result) {
        if (result.finalResult) {
          _symptomController.text = result.recognizedWords;
          setState(() => _isListening = false);
        }
      },
      localeId: _selectedLang,
    );
  }

  Future<void> _analyze() async {
    final text = _symptomController.text.trim();
    if (text.isEmpty) return;

    setState(() {
      _isAnalyzing = true;
      _result = null;
      _error = null;
    });

    try {
      final result = await GeminiService.triageSymptoms(
        symptoms: text,
        language: _selectedLang,
      );

      // Log analytics event
      try {
        final pos = await Geolocator.getLastKnownPosition();
        if (pos != null) {
          await FirebaseService().logTriageEvent(
            urgencyLevel: result.urgency.name,
            lat: pos.latitude,
            lng: pos.longitude,
            language: _selectedLang,
          );
        }
      } catch (_) {}

      setState(() => _result = result);
    } catch (e) {
      setState(() => _error = 'Analysis failed. Please try again.');
    } finally {
      setState(() => _isAnalyzing = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('AI Symptom Triage'),
        backgroundColor: const Color(0xFF131820),
        elevation: 0,
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 16),
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: const Color(0xFF1D9E75).withOpacity(0.15),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: const Color(0xFF1D9E75).withOpacity(0.3)),
            ),
            child: const Text('Powered by Gemini',
                style: TextStyle(fontSize: 11, color: Color(0xFF1D9E75))),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Language selector
            Text('Select Language',
                style: theme.textTheme.labelSmall
                    ?.copyWith(color: Colors.white38, letterSpacing: 0.8)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 6,
              children: _languages
                  .map((lang) => LanguagePill(
                        label: lang['label']!,
                        isActive: _selectedLang == lang['code'],
                        onTap: () =>
                            setState(() => _selectedLang = lang['code']!),
                      ))
                  .toList(),
            ),
            const SizedBox(height: 16),

            // Symptom input
            Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  children: [
                    TextField(
                      controller: _symptomController,
                      maxLines: 4,
                      style: const TextStyle(fontSize: 14),
                      decoration: InputDecoration(
                        hintText: 'Describe how you\'re feeling...',
                        hintStyle: TextStyle(color: Colors.white24),
                        border: InputBorder.none,
                        suffixIcon: IconButton(
                          icon: Icon(
                            _isListening ? Icons.mic : Icons.mic_none,
                            color: _isListening
                                ? const Color(0xFF1D9E75)
                                : Colors.white38,
                          ),
                          onPressed: _isListening ? _speech.stop : _startListening,
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    SizedBox(
                      width: double.infinity,
                      child: FilledButton.icon(
                        onPressed: _isAnalyzing ? null : _analyze,
                        icon: _isAnalyzing
                            ? const SizedBox(
                                width: 16,
                                height: 16,
                                child: CircularProgressIndicator(
                                    strokeWidth: 2, color: Colors.white))
                            : const Icon(Icons.bolt),
                        label: Text(
                            _isAnalyzing ? 'Analyzing with Gemini AI...' : 'Analyze Symptoms'),
                        style: FilledButton.styleFrom(
                          backgroundColor: const Color(0xFF1D9E75),
                          padding: const EdgeInsets.symmetric(vertical: 14),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),

            if (_error != null) ...[
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: const Color(0xFFE24B4A).withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: const Color(0xFFE24B4A).withOpacity(0.3)),
                ),
                child: Text(_error!, style: const TextStyle(color: Color(0xFFE24B4A))),
              ),
            ],

            if (_result != null) ...[
              const SizedBox(height: 16),
              TriageResultCard(result: _result!),
            ],
          ],
        ),
      ),
    );
  }
}
