import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';

import '../services/maps_service.dart';
import '../services/firebase_service.dart';
import '../models/facility.dart';
import '../widgets/facility_tile.dart';

class FacilityMapScreen extends StatefulWidget {
  const FacilityMapScreen({super.key});

  @override
  State<FacilityMapScreen> createState() => _FacilityMapScreenState();
}

class _FacilityMapScreenState extends State<FacilityMapScreen> {
  GoogleMapController? _mapController;
  Position? _userPosition;
  List<Facility> _facilities = [];
  Set<Marker> _markers = {};
  bool _loading = true;
  String _filter = 'all';
  int? _selectedIndex;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    try {
      _userPosition = await MapsService.getCurrentLocation();
      await _loadFacilities();
    } catch (e) {
      setState(() => _loading = false);
    }
  }

  Future<void> _loadFacilities() async {
    if (_userPosition == null) return;

    final fromFirestore = await FirebaseService().getNearbyFacilities(
      lat: _userPosition!.latitude,
      lng: _userPosition!.longitude,
    );

    final markers = <Marker>{};
    for (int i = 0; i < fromFirestore.length; i++) {
      final f = fromFirestore[i];
      markers.add(Marker(
        markerId: MarkerId(f.id),
        position: LatLng(f.lat, f.lng),
        infoWindow: InfoWindow(
          title: f.name,
          snippet: f.status == FacilityStatus.open ? 'Open' : 'Closed',
        ),
        onTap: () => setState(() => _selectedIndex = i),
        icon: BitmapDescriptor.defaultMarkerWithHue(
          f.status == FacilityStatus.open
              ? BitmapDescriptor.hueGreen
              : BitmapDescriptor.hueRed,
        ),
      ));
    }

    setState(() {
      _facilities = fromFirestore;
      _markers = markers;
      _loading = false;
    });
  }

  List<Facility> get _filteredFacilities {
    if (_filter == 'all') return _facilities;
    return _facilities
        .where((f) => f.type.name == _filter)
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Find Care Near You'),
        backgroundColor: const Color(0xFF131820),
        elevation: 0,
      ),
      body: Column(
        children: [
          // Filter chips
          SizedBox(
            height: 48,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              children: [
                for (final label in ['all', 'hospital', 'clinic', 'pharmacy', 'chw'])
                  Padding(
                    padding: const EdgeInsets.only(right: 6),
                    child: FilterChip(
                      label: Text(label[0].toUpperCase() + label.substring(1)),
                      selected: _filter == label,
                      onSelected: (_) => setState(() => _filter = label),
                      selectedColor: const Color(0xFF1D9E75).withOpacity(0.2),
                      checkmarkColor: const Color(0xFF1D9E75),
                    ),
                  ),
              ],
            ),
          ),

          // Map
          if (_loading)
            const Expanded(child: Center(child: CircularProgressIndicator()))
          else if (_userPosition != null)
            SizedBox(
              height: 260,
              child: GoogleMap(
                onMapCreated: (ctrl) => _mapController = ctrl,
                initialCameraPosition: CameraPosition(
                  target: LatLng(_userPosition!.latitude, _userPosition!.longitude),
                  zoom: 13,
                ),
                markers: _markers,
                myLocationEnabled: true,
                myLocationButtonEnabled: true,
              ),
            ),

          // Facility list
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: _filteredFacilities.length,
              itemBuilder: (context, i) => FacilityTile(
                facility: _filteredFacilities[i],
                isSelected: _selectedIndex == i,
                userLat: _userPosition?.latitude,
                userLng: _userPosition?.longitude,
                onTap: () {
                  setState(() => _selectedIndex = i);
                  final f = _filteredFacilities[i];
                  _mapController?.animateCamera(
                    CameraUpdate.newLatLngZoom(LatLng(f.lat, f.lng), 15),
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}
