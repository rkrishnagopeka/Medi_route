import 'package:flutter/material.dart';
import '../services/firebase_service.dart';
import '../models/chw.dart';

class ChwScreen extends StatefulWidget {
  const ChwScreen({super.key});

  @override
  State<ChwScreen> createState() => _ChwScreenState();
}

class _ChwScreenState extends State<ChwScreen> {
  List<Chw> _chws = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadCHWs();
  }

  Future<void> _loadCHWs() async {
    try {
      // Using a default location (update with real geolocator)
      final chws = await FirebaseService().getNearbyCHWs(
        lat: 13.0827,
        lng: 80.2707,
      );
      setState(() {
        _chws = chws;
        _loading = false;
      });
    } catch (_) {
      setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Community Health Workers'),
        backgroundColor: const Color(0xFF131820),
        elevation: 0,
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _chws.isEmpty
              ? _buildEmpty()
              : ListView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: _chws.length,
                  itemBuilder: (context, i) => _ChwCard(chw: _chws[i]),
                ),
    );
  }

  Widget _buildEmpty() {
    return const Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.people_outline, size: 64, color: Colors.white24),
          SizedBox(height: 12),
          Text('No CHWs found nearby',
              style: TextStyle(color: Colors.white38)),
        ],
      ),
    );
  }
}

class _ChwCard extends StatelessWidget {
  final Chw chw;
  const _ChwCard({required this.chw});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: const Color(0xFF7F77DD).withOpacity(0.2),
          child: Text(chw.name[0],
              style: const TextStyle(color: Color(0xFF7F77DD))),
        ),
        title: Text(chw.name),
        subtitle: Text('${chw.casesHandled} cases handled'),
        trailing: chw.available
            ? FilledButton(
                onPressed: () {},
                style: FilledButton.styleFrom(
                  backgroundColor: const Color(0xFF1D9E75),
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                ),
                child: const Text('Request', style: TextStyle(fontSize: 12)),
              )
            : const Chip(label: Text('Busy')),
      ),
    );
  }
}
