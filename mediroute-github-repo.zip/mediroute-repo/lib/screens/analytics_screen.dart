import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';

class AnalyticsScreen extends StatelessWidget {
  const AnalyticsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Health Analytics'),
        backgroundColor: const Color(0xFF131820),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Stat cards
            GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisSpacing: 10,
              mainAxisSpacing: 10,
              childAspectRatio: 1.5,
              children: const [
                _StatCard(label: 'Triages Today', value: '247', delta: '+12%'),
                _StatCard(label: 'Avg Wait Time', value: '18 min', delta: '-3 min'),
                _StatCard(label: 'CHW Visits', value: '89', delta: '+7%'),
                _StatCard(label: 'Emergencies', value: '14', delta: '+2'),
              ],
            ),
            const SizedBox(height: 20),

            // Bar chart
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Triage by Urgency (Last 7 Days)',
                        style: TextStyle(fontWeight: FontWeight.w600)),
                    const SizedBox(height: 16),
                    SizedBox(
                      height: 180,
                      child: BarChart(
                        BarChartData(
                          alignment: BarChartAlignment.spaceAround,
                          maxY: 100,
                          barGroups: _buildBarGroups(),
                          borderData: FlBorderData(show: false),
                          gridData: FlGridData(
                            show: true,
                            drawVerticalLine: false,
                            horizontalInterval: 25,
                            getDrawingHorizontalLine: (v) => const FlLine(
                              color: Colors.white12,
                              strokeWidth: 1,
                            ),
                          ),
                          titlesData: FlTitlesData(
                            leftTitles: const AxisTitles(
                                sideTitles: SideTitles(showTitles: false)),
                            rightTitles: const AxisTitles(
                                sideTitles: SideTitles(showTitles: false)),
                            topTitles: const AxisTitles(
                                sideTitles: SideTitles(showTitles: false)),
                            bottomTitles: AxisTitles(
                              sideTitles: SideTitles(
                                showTitles: true,
                                getTitlesWidget: (v, _) {
                                  const days = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];
                                  return Text(days[v.toInt()],
                                      style: const TextStyle(
                                          fontSize: 11, color: Colors.white38));
                                },
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<BarChartGroupData> _buildBarGroups() {
    final data = [
      [42.0, 31.0, 12.0],
      [55.0, 28.0, 8.0],
      [38.0, 45.0, 15.0],
      [62.0, 33.0, 10.0],
      [70.0, 38.0, 18.0],
      [30.0, 20.0, 6.0],
      [25.0, 18.0, 4.0],
    ];

    return data.asMap().entries.map((entry) {
      return BarChartGroupData(
        x: entry.key,
        barRods: [
          BarChartRodData(
              toY: entry.value[0],
              color: const Color(0xFF1D9E75),
              width: 8,
              borderRadius: BorderRadius.circular(3)),
          BarChartRodData(
              toY: entry.value[1],
              color: const Color(0xFFBA7517),
              width: 8,
              borderRadius: BorderRadius.circular(3)),
          BarChartRodData(
              toY: entry.value[2],
              color: const Color(0xFFE24B4A),
              width: 8,
              borderRadius: BorderRadius.circular(3)),
        ],
      );
    }).toList();
  }
}

class _StatCard extends StatelessWidget {
  final String label;
  final String value;
  final String delta;

  const _StatCard(
      {required this.label, required this.value, required this.delta});

  @override
  Widget build(BuildContext context) {
    final isPositive = delta.startsWith('+');
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(label,
                style: const TextStyle(fontSize: 11, color: Colors.white38)),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(value,
                    style: const TextStyle(
                        fontSize: 24, fontWeight: FontWeight.bold)),
                Text(delta,
                    style: TextStyle(
                        fontSize: 11,
                        color: isPositive
                            ? const Color(0xFF1D9E75)
                            : const Color(0xFFE24B4A))),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
