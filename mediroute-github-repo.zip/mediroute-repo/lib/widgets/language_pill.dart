import 'package:flutter/material.dart';

class LanguagePill extends StatelessWidget {
  final String label;
  final bool isActive;
  final VoidCallback onTap;

  const LanguagePill({
    super.key,
    required this.label,
    required this.isActive,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: isActive
              ? const Color(0xFF1D9E75).withOpacity(0.15)
              : const Color(0xFF1A2130),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: isActive
                ? const Color(0xFF1D9E75).withOpacity(0.5)
                : Colors.white.withOpacity(0.12),
          ),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w500,
            color: isActive ? const Color(0xFF1D9E75) : Colors.white54,
          ),
        ),
      ),
    );
  }
}
