import 'package:flutter/material.dart';
import '../models/facility.dart';
import '../services/maps_service.dart';

class FacilityTile extends StatelessWidget {
  final Facility facility;
  final bool isSelected;
  final double? userLat;
  final double? userLng;
  final VoidCallback? onTap;

  const FacilityTile({
    super.key,
    required this.facility,
    this.isSelected = false,
    this.userLat,
    this.userLng,
    this.onTap,
  });

  Color get _statusColor => switch (facility.status) {
        FacilityStatus.open => const Color(0xFF1D9E75),
        FacilityStatus.busy => const Color(0xFFBA7517),
        FacilityStatus.closed => const Color(0xFFE24B4A),
      };

  IconData get _typeIcon => switch (facility.type) {
        FacilityType.hospital => Icons.local_hospital,
        FacilityType.clinic => Icons.medical_services,
        FacilityType.pharmacy => Icons.local_pharmacy,
        FacilityType.chw => Icons.person_pin,
      };

  @override
  Widget build(BuildContext context) {
    final distKm = (userLat != null && userLng != null)
        ? MapsService.distanceBetween(
            userLat!, userLng!, facility.lat, facility.lng)
        : null;

    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: isSelected
              ? const Color(0xFF1D9E75).withOpacity(0.08)
              : const Color(0xFF1E2736),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: isSelected
                ? const Color(0xFF1D9E75).withOpacity(0.4)
                : Colors.white.withOpacity(0.07),
          ),
        ),
        child: Row(
          children: [
            Container(
              width: 40, height: 40,
              decoration: BoxDecoration(
                color: _statusColor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(_typeIcon, color: _statusColor, size: 20),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(facility.name,
                      style: const TextStyle(
                          fontWeight: FontWeight.w600, fontSize: 14),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis),
                  const SizedBox(height: 2),
                  Text(facility.address,
                      style: const TextStyle(
                          fontSize: 11, color: Colors.white38),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 7, vertical: 2),
                        decoration: BoxDecoration(
                          color: _statusColor.withOpacity(0.12),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text(
                          facility.status.name[0].toUpperCase() +
                              facility.status.name.substring(1),
                          style: TextStyle(
                              fontSize: 10,
                              color: _statusColor,
                              fontWeight: FontWeight.w600),
                        ),
                      ),
                      if (facility.waitMinutes != null) ...[
                        const SizedBox(width: 6),
                        Text('${facility.waitMinutes} min wait',
                            style: const TextStyle(
                                fontSize: 10, color: Colors.white38)),
                      ],
                      if (distKm != null) ...[
                        const SizedBox(width: 6),
                        Text('${distKm.toStringAsFixed(1)} km',
                            style: const TextStyle(
                                fontSize: 10, color: Colors.white38)),
                      ],
                    ],
                  ),
                ],
              ),
            ),
            const Icon(Icons.chevron_right, color: Colors.white24, size: 18),
          ],
        ),
      ),
    );
  }
}
