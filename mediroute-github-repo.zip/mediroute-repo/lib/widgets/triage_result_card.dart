import 'package:flutter/material.dart';
import '../models/triage_result.dart';

class TriageResultCard extends StatelessWidget {
  final TriageResult result;
  const TriageResultCard({super.key, required this.result});

  Color get _urgencyColor => switch (result.urgency) {
        UrgencyLevel.emergency => const Color(0xFFE24B4A),
        UrgencyLevel.urgent => const Color(0xFFBA7517),
        UrgencyLevel.homeCare => const Color(0xFF1D9E75),
      };

  IconData get _urgencyIcon => switch (result.urgency) {
        UrgencyLevel.emergency => Icons.emergency,
        UrgencyLevel.urgent => Icons.schedule,
        UrgencyLevel.homeCare => Icons.home,
      };

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header
            Row(
              children: [
                Container(
                  width: 44, height: 44,
                  decoration: BoxDecoration(
                    color: _urgencyColor.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: _urgencyColor.withOpacity(0.3)),
                  ),
                  child: Icon(_urgencyIcon, color: _urgencyColor, size: 22),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(result.urgencyLabel,
                          style: TextStyle(
                              color: _urgencyColor,
                              fontWeight: FontWeight.bold,
                              fontSize: 15)),
                      Text(result.urgencySubtitle,
                          style: const TextStyle(
                              color: Colors.white38, fontSize: 12)),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),

            // Explanation
            Text(result.explanation,
                style: const TextStyle(fontSize: 14, height: 1.5)),
            const SizedBox(height: 12),

            // Next step
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.04),
                borderRadius: BorderRadius.circular(8),
                border: Border(left: BorderSide(color: _urgencyColor, width: 3)),
              ),
              child: Text(result.nextStep,
                  style: const TextStyle(fontSize: 13)),
            ),
            const SizedBox(height: 14),

            // Confidence bar
            Row(
              children: [
                const Text('AI Confidence: ',
                    style: TextStyle(fontSize: 11, color: Colors.white38)),
                Text('${result.confidence}%',
                    style: TextStyle(
                        fontSize: 11,
                        color: _urgencyColor,
                        fontWeight: FontWeight.w600)),
              ],
            ),
            const SizedBox(height: 6),
            ClipRRect(
              borderRadius: BorderRadius.circular(3),
              child: LinearProgressIndicator(
                value: result.confidence / 100,
                backgroundColor: Colors.white12,
                valueColor: AlwaysStoppedAnimation(_urgencyColor),
                minHeight: 4,
              ),
            ),

            // Red flags
            if (result.redFlags.isNotEmpty) ...[
              const SizedBox(height: 14),
              const Text('⚠️ Watch for these signs:',
                  style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: Colors.white54)),
              const SizedBox(height: 6),
              Wrap(
                spacing: 6,
                runSpacing: 6,
                children: result.redFlags
                    .map((flag) => Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: const Color(0xFFE24B4A).withOpacity(0.1),
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Text(flag,
                              style: const TextStyle(
                                  fontSize: 11, color: Color(0xFFE24B4A))),
                        ))
                    .toList(),
              ),
            ],

            const SizedBox(height: 14),
            // Action buttons
            Row(
              children: [
                Expanded(
                  child: FilledButton.icon(
                    onPressed: () => Navigator.pushNamed(context, '/facilities'),
                    icon: const Icon(Icons.map, size: 16),
                    label: const Text('Find Facility'),
                    style: FilledButton.styleFrom(
                        backgroundColor: _urgencyColor),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => Navigator.pushNamed(context, '/chw'),
                    icon: const Icon(Icons.people, size: 16),
                    label: const Text('Call CHW'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
