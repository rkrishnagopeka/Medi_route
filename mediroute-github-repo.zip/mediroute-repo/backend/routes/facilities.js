const express = require('express');
const router = express.Router();
const admin = require('firebase-admin');

/**
 * GET /api/facilities?lat=&lng=&radius=
 */
router.get('/', async (req, res) => {
  const { lat, lng, radius = 10 } = req.query;

  if (!lat || !lng) {
    return res.status(400).json({ error: 'lat and lng are required' });
  }

  try {
    const db = admin.firestore();
    const delta = parseFloat(radius) / 111.0;
    const latF = parseFloat(lat);
    const lngF = parseFloat(lng);

    const snap = await db.collection('facilities')
      .where('lat', '>', latF - delta)
      .where('lat', '<', latF + delta)
      .get();

    const facilities = snap.docs
      .map(doc => ({ id: doc.id, ...doc.data() }))
      .filter(f => Math.abs(f.lng - lngF) < delta);

    res.json({ facilities, count: facilities.length });
  } catch (err) {
    console.error('Facilities error:', err);
    res.status(500).json({ error: 'Failed to fetch facilities' });
  }
});

/**
 * PUT /api/facilities/:id — Update status (for facility staff dashboard)
 */
router.put('/:id', async (req, res) => {
  const { id } = req.params;
  const { status, waitMinutes, availableMeds } = req.body;

  try {
    const db = admin.firestore();
    await db.collection('facilities').doc(id).update({
      ...(status && { status }),
      ...(waitMinutes !== undefined && { waitMinutes }),
      ...(availableMeds && { availableMeds }),
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
    });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Update failed' });
  }
});

module.exports = router;
