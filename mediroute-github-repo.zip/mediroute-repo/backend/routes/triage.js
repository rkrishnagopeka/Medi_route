const express = require('express');
const router = express.Router();
const { GoogleGenerativeAI } = require('@google/generative-ai');

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

/**
 * POST /api/triage
 * Body: { symptoms: string, language: string }
 */
router.post('/', async (req, res) => {
  const { symptoms, language = 'en' } = req.body;

  if (!symptoms || symptoms.trim().length < 3) {
    return res.status(400).json({ error: 'Symptoms text is required' });
  }

  try {
    const model = genAI.getGenerativeModel({ model: 'gemini-pro' });

    const prompt = `
You are MediRoute's AI triage assistant. A patient from an underserved community has described their symptoms.
Provide a structured triage response in ${language}.

Patient symptoms: "${symptoms}"

Respond ONLY in valid JSON with this exact structure:
{
  "urgency": "emergency" | "urgent" | "home_care",
  "urgencyLabel": "Go Now Immediately" | "Visit Clinic Soon" | "Home Care Recommended",
  "urgencySubtitle": "Brief subtitle in plain language",
  "explanation": "2-3 sentence plain-language explanation appropriate for low-literacy users",
  "nextStep": "Single most important next action",
  "confidence": 0-100,
  "redFlags": ["list", "of", "warning", "signs"],
  "homeRemedies": ["tip1", "tip2"]
}

Rules:
- Use simple language a non-medical person understands
- Never diagnose — only triage
- Be compassionate and clear
`;

    const result = await model.generateContent(prompt);
    const text = result.response.text();

    // Parse JSON from response
    const cleaned = text.replace(/```json|```/g, '').trim();
    const parsed = JSON.parse(cleaned);

    return res.json(parsed);
  } catch (err) {
    console.error('Triage error:', err);
    return res.status(500).json({ error: 'Triage analysis failed' });
  }
});

module.exports = router;
