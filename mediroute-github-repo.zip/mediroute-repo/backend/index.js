const express = require('express');
const cors = require('cors');
const triageRoutes = require('./routes/triage');
const facilitiesRoutes = require('./routes/facilities');

const app = express();
const PORT = process.env.PORT || 8080;

app.use(cors());
app.use(express.json());

// Health check
app.get('/', (req, res) => {
  res.json({ status: 'ok', service: 'MediRoute API', version: '1.0.0' });
});

// Routes
app.use('/api/triage', triageRoutes);
app.use('/api/facilities', facilitiesRoutes);

app.listen(PORT, () => {
  console.log(`MediRoute backend running on port ${PORT}`);
});
